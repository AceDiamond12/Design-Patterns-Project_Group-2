# JavaFX Paint Application (v2)

## Run
```bash
mvn -U clean javafx:run
```
Main class: `src/main/java/paint/Paint.java`
Start FXML: `src/main/resources/paint/view/start.fxml`
Main  FXML: `src/main/resources/paint/view/main.fxml`
