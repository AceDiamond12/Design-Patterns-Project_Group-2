package paint.controller;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import paint.model.Shape;           // <-- مهم: واجهة الشكل من الباكدج حقنا
import paint.view.FxShapeAdapter;

public class MainController {

    @FXML private ComboBox<String> shapeBox;
    @FXML private ColorPicker colorPicker;
    @FXML private Pane canvasPane;
    @FXML private ListView<String> shapesList;

    private final List<Shape> shapes = new ArrayList<>();
    private final Deque<List<Shape>> undoStack = new ArrayDeque<>();
    private final Deque<List<Shape>> redoStack = new ArrayDeque<>();

    @FXML
    private void initialize() {
        shapeBox.getItems().addAll("Rectangle","Circle","Line","Ellipse","Triangle","Square");
        shapeBox.getSelectionModel().selectFirst();
        colorPicker.setValue(javafx.scene.paint.Color.BLACK);
        refreshUI();
    }

    @FXML
    private void canvasClicked(MouseEvent e) {
        String type = shapeBox.getValue();
        javafx.scene.paint.Color c = colorPicker.getValue();
        Shape s = ShapeFactory.createShape(type, e.getX(), e.getY(), c);
        pushUndo();
        shapes.add(s);
        redoStack.clear();
        refreshUI();
    }

    @FXML private void copySelected()   { mutateSelected((s) -> { pushUndo(); shapes.add(s.copy()); }); }
    @FXML private void deleteSelected() { mutateSelected((s) -> { pushUndo(); shapes.remove(s); }); }
    @FXML private void recolorSelected(){ mutateSelected((s) -> { pushUndo(); s.setColor(colorPicker.getValue()); }); }
    @FXML private void moveSelected()   { mutateSelected((s) -> { pushUndo(); s.moveBy(15,10); }); }
    @FXML private void resizeSelected() { mutateSelected((s) -> { pushUndo(); s.scaleBy(1.1); }); }

    @FXML
    private void undo() {
        if (undoStack.isEmpty()) return;
        redoStack.push(snapshot(shapes));
        shapes.clear();
        shapes.addAll(undoStack.pop());
        refreshUI();
    }

    @FXML
    private void redo() {
        if (redoStack.isEmpty()) return;
        undoStack.push(snapshot(shapes));
        shapes.clear();
        shapes.addAll(redoStack.pop());
        refreshUI();
    }

    @FXML private void saveFile()   { info("Save", "SaveToXML placeholder."); }
    @FXML private void loadFile()   { info("Load", "LoadFromXML placeholder."); }
    @FXML private void importFile() { info("Import", "Import placeholder."); }

    /* Helpers */
    private interface Mut { void apply(Shape s); }
    private void mutateSelected(Mut mut) {
        int idx = shapesList.getSelectionModel().getSelectedIndex();
        if (idx < 0 || idx >= shapes.size()) { info("Selection", "اختر شكلاً من القائمة أولاً."); return; }
        mut.apply(shapes.get(idx));
        redoStack.clear();
        refreshUI();
    }
    private void refreshUI() {
        canvasPane.getChildren().clear();
        for (Shape s : shapes) {
            Node n = FxShapeAdapter.toNode(s);
            canvasPane.getChildren().add(n);
        }
        shapesList.getItems().setAll(shapes.stream().map(Shape::label).toList());
    }
    private void pushUndo() { undoStack.push(snapshot(shapes)); }
    private List<Shape> snapshot(List<Shape> src) {
        List<Shape> copy = new ArrayList<>(src.size());
        for (Shape s : src) copy.add(s.copy());
        return copy;
    }
    private void info(String h, String m) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setHeaderText(h); a.setContentText(m); a.showAndWait();
    }
}
